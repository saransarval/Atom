#ifndef Atom_Blink
#define Atom_Blink

#include "Arduino.h"


class Blink
{
public:
     init(unsigned int pin_number);
     Blink_Default();
     Blink_Delay(int delay_in_sec);
     Blink_No_Delay();
    int ms_delay;
private:
      int  _pin;
    //

  
};

#endif

