#include "Arduino.h"
#include "Atom_Blink.h"


Blink::init(unsigned int pin_number)
{

  pinMode(pin_number,OUTPUT);
  _pin=pin_number;
}

Blink::Blink_Default()
{

  digitalWrite(_pin,HIGH);
  delay(500);
  digitalWrite(_pin,LOW);
  delay(500);
}
Blink::Blink_Delay(int delay_in_sec)
{
  ms_delay=delay_in_sec*1000;
  digitalWrite(_pin,HIGH);
  delay(ms_delay);
  digitalWrite(_pin,LOW);
  delay(ms_delay);
  
}

Blink::Blink_No_Delay()
{
  digitalWrite(_pin,HIGH);
  delay(10);
  digitalWrite(_pin,LOW);
  delay(10);  
}

